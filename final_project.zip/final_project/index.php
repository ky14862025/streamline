<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Document</title>
  <link rel="stylesheet" href=..\final_project\css\style.css>
</head>

<body>
  <section>
    <div class="circle">

    </div>
    <header>
      <a href="..\final_project\index.php"> <img src="images/streamlinelogo.png" class="logo" /></a>

    </header>
    <div class="navbar">
      <ul>
        <li><a href="..\final_project\login\SignupPage.php" class="nav-link"> Sign Up</a></li>
        <li><a href="..\final_project\login\Loginpage.php" class="nav-link">Login</a></li>
        <li><a href="#"> Contact Us</a></li>
      </ul>
    </div>
    <div class="content">
      <div class=" textBox">
        <h2>Stop drowning in tasks<br> Streamline your work with us<span></span></h2>
        <p>Streamline your team's work with Streamline. This all-in-one workflow management app helps teams collaborate, automate tasks, and hit deadlines. Try Streamline for Free and see how easy it is to boost your team's productivity!</p>
        <a href="..\final_project\view\AboutUs.php"> Learn More</a>

      </div>
      <div class="imgBox">
        <img src="images\workflowmanagement.png" class="workflow">


      </div>
   



    </div>
  </section>

 
</body>

</html>