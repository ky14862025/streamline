<?php
// Check if the task ID is present in the URL parameters
if(isset($_GET['task_id'])) {
    $taskId = $_GET['task_id'];
} else {
    // If task ID is not present, you may need to handle this case appropriately
    // For example, redirecting the user to an error page or displaying an error message.
    die("Task ID not provided.");
}

// Check if file is uploaded
if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
    // Include database connection
    include '../settings/connection.php';

    // Create upload directory if it doesn't exist
    $uploadDirectory = "../uploads/";
    if (!file_exists($uploadDirectory)) {
        if (!mkdir($uploadDirectory, 0777, true)) {
            die("Error creating upload directory.");
        }
    }

    // Validate task ID
    if (!is_numeric($taskId)) {
        die("Invalid task ID.");
    }

    // Get file details
    $file = $_FILES['attachment'];

    // Validate file size and type
    $allowedExtensions = ['pdf', 'doc', 'docx', 'txt', 'jpg', 'jpeg', 'png', 'gif'];
    $maxFileSize = 50 * 1024 * 1024; // 50MB
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($fileExtension, $allowedExtensions) || $file['size'] > $maxFileSize) {
        die("Invalid file format or size.");
    }

    // Generate unique filename
    $filename = uniqid() . '_' . $file['name'];

    // Move uploaded file to the upload directory
    if (move_uploaded_file($file['tmp_name'], $uploadDirectory . $filename)) {
        // File uploaded successfully, insert details into database
        $attachmentType = $file['type'];
        $attachmentUrl = $uploadDirectory . $filename; // Full path to the file
        
        // Insert attachment details into Attachments table
        $sql = "INSERT INTO Attachments (task_id, attachment_type, attachment_url) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $taskId, $attachmentType, $attachmentUrl);

        if ($stmt->execute()) {
            echo "Attachment uploaded successfully.";
        } else {
            echo "Error uploading attachment to database: " . $conn->error;
        }
    } else {
        echo "Error moving file to upload directory.";
    }
} else {
    echo "No file uploaded or an error occurred during upload.";
}
?>
