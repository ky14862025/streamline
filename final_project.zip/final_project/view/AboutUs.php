<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <title>About Us</title>

    
    <style>
        @import url('https://fonts.googleapis.com/css?family=Poppins: 200,300,400,500,600,700,800,900&display=swap');
*{
    margin:0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}
      
        body{
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .section{
            max-width: 1200px;
            margin: 0 auto;
            padding: 50px 20px;
            text-align: center;
        }

        .title h1{
            font-size: 42px;
            margin-bottom: 30px;
        }

        .services{
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        /* Style for cards */
        .card {
            flex: 0 1 calc(30% - 20px);
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            margin: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: left;
        }

        .icon {
            font-size: 48px;
            margin-bottom: 20px;
            color: #333;
        }

        h2 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #333;
        }

        p {
            font-size: 16px;
            margin-bottom: 20px;
            color: #666;
        }

        .button {
            display: inline-block;
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #333;
        }

        @media screen and (max-width: 768px) {
            .card {
                flex: 0 1 calc(50% - 20px);
            }
        }

        @media screen and (max-width: 576px) {
            .card {
                flex: 0 1 calc(100% - 20px);
            }
        }
    </style>
</head>
<body>
    <div class="section">
        <div class="title">
            <h1>About Us</h1>
            <p>We are here to simplify your life.</p>
        </div>
        <div class="services">
            <div class="card">
                <div class="icon">
                    <i class="fas fa-calendar"></i>
                </div>
                <h2>Task Management</h2>
                <p>Feeling overwhelmed by your to-do list? We can help! Our task management system lets you organize your workload effortlessly.</p>
                <a href="..\index.php" class="button">Home</a>
            </div>
            
            <div class="card">
                <div class="icon">
                    <i class="fas fa-handshake"></i>
                </div>
                <h2>Collaborative Services</h2>
                <p>Teamwork makes the dream work! Our collaboration features help you and your team stay connected and productive.</p>
                <a href="..\index.php" class="button">Home</a>
            </div>
            
            <div class="card">
                <div class="icon">
                    <i class="fas fa-bell"></i>
                </div>
                <h2>Notifications</h2>
                <p>Stay on top of your work with our built-in notification system. Never miss a deadline again!</p>
                <a href="..\index.php" class="button">Home</a>
            </div>
        </div>
    </div>
</body>
</html>
