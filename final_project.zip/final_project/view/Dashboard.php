<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../login/Loginpage.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        @import url('https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap');

body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    background-color: #fff;
}

.container {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}

header {
    background-color: #fff;
    color: #333;
    padding: 20px;
    text-align: center;
    border-radius: 10px;
}

.card-container {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
}

.card {
    width: 48%;
    background-color: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease;
    margin-left: 20px;
}

.card:hover {
    transform: translateY(-5px);
}

.card h2 {
    font-size: 24px;
    margin-bottom: 10px;
}

.card p {
    font-size: 16px;
    color: #666;
    margin-bottom: 20px;
}

.card a {
    display: inline-block;
    background-color: #333;
    color: #fff;
    text-decoration: none;
    padding: 10px 20px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.card a:hover {
    background-color: #0056b3;
}

    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Welcome back, <?php echo $_SESSION['username']; ?>!</h1>
        </header>
        <div class="card-container">
            <div class="card">
                <h2>Individual Boards</h2>
                <p>Create and manage your personal boards here.</p>
                <a href=  ../view/create_board.php id="individual_board_link">Create Individual Board</a>
            </div>
            <div class="card">
                <h2>Team Boards</h2>
                <p>Create and collaborate on team boards here.</p>
                <a href= ../view/create_team_board.php  id="team_board_link">Create Team Board</a>
            </div>
        </div>
        <div id="content"></div>
    </div>

</body>
</html>
