<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Board</title>
    <style>
         @import url('https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap');
          body {
            font-family: Poppins, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #fff;
        }

        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Create Board</h1>

    <!-- Form for creating a board -->
    <form action="../action/create_board_action.php" method="post">
        <label for="board_name">Board Name:</label>
        <input type="text" id="board_name" name="board_name" required><br>
        <button type="submit">Create Board</button>
    </form>


    <h1>Return to Board</h1>

<!-- Form for returning to a board -->
<form action="../action/already_existing_board_action.php" method="post">
    <label for="board_name">Board Name:</label>
    <input type="text" id="board_name" name="board_name" required><br>
    <button type="submit">Return to Board</button>
</form>


</body>
</html>
