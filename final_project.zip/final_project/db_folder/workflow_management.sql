-- Create the database
CREATE DATABASE IF NOT EXISTS workflow_management;
USE workflow_management;

-- Users Table
CREATE TABLE IF NOT EXISTS Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(100) NOT NULL
);

-- Boards Table
CREATE TABLE IF NOT EXISTS Boards (
    board_id INT AUTO_INCREMENT PRIMARY KEY,
    board_name VARCHAR(100) unique NOT NULL,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES Users(user_id)
);

-- Tasks Table
CREATE TABLE IF NOT EXISTS Tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    board_id INT,
    task_name VARCHAR(255) NOT NULL,
    description TEXT,
    due_date DATE,
    assignee_id INT,
    status ENUM('Not Started', 'In Progress', 'Completed'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (board_id) REFERENCES Boards(board_id),
    FOREIGN KEY (assignee_id) REFERENCES Users(user_id)
);

-- Comments Table
CREATE TABLE IF NOT EXISTS Comments (
    comment_id INT AUTO_INCREMENT PRIMARY KEY,
    task_id INT,
    user_id INT,
    comment_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (task_id) REFERENCES Tasks(task_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);

-- Attachments Table
CREATE TABLE IF NOT EXISTS Attachments (
    attachment_id INT AUTO_INCREMENT PRIMARY KEY,
    task_id INT,
    attachment_type VARCHAR(50) NOT NULL,
    attachment_url VARCHAR(255) NOT NULL,
    FOREIGN KEY (task_id) REFERENCES Tasks(task_id)
);

-- Labels Table
CREATE TABLE IF NOT EXISTS Labels (
    label_id INT AUTO_INCREMENT PRIMARY KEY,
    label_name VARCHAR(100) NOT NULL,
    board_id INT,
    color VARCHAR(20),
    FOREIGN KEY (board_id) REFERENCES Boards(board_id)
);
CREATE TABLE IF NOT EXISTS Team_Boards (
    team_board_id INT AUTO_INCREMENT PRIMARY KEY,
    board_id INT,
    team_name VARCHAR(100) NOT NULL,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (board_id) REFERENCES Boards(board_id),
    FOREIGN KEY (created_by) REFERENCES Users(user_id)
);
CREATE TABLE IF NOT EXISTS Team_members (
    team_member_id INT AUTO_INCREMENT PRIMARY KEY,
    team_board_id INT,
    user_id INT,
    FOREIGN KEY (team_board_id) REFERENCES Team_Boards(team_board_id),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
);


ALTER TABLE Users
ADD COLUMN gender VARCHAR(10),
ADD COLUMN date_of_birth DATE,
ADD COLUMN phone_number VARCHAR(20);
